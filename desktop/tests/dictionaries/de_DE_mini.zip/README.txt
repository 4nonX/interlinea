A small German word list for the tests.
