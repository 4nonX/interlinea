A small English word list for the tests.
